<FORM>
<button type="button" onclick="parent.location='start.php'">Start Trace</button>
</FORM>
<FORM>
<button type="button" onclick="parent.location='stop.php'">Stop Trace</button>
</FORM>
