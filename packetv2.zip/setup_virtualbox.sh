#!/bin/bash
# This is the initial file to set up the Raspberry Pi Network Packet Capture by Morgan Burns

# Make sure that the system is up to date
sudo apt-get install update

# Installing prerequisites
sudo apt-get install bridge-utils

# Setting up the bridge between the two network cards. 
## Shutdown both interfaces first
sudo ifconfig enp0s3 down
sudo ifconfig enp0s8 down

# Set interfaces to promiscuous mode
sudo ifconfig enp0s3 0.0.0.0 promisc up
sudo ifconfig emp0s8 0.0.0.0 promisc up

# Add both interfaces to virtual bridge network
sudo brctl addbr br0
sudo brctl addif br0 enp0s3
sudo brctl addif br0 enp0s8

## Configure an IP to the bridge to allow remote access
sudo ifconfig br0 192.168.10.254 netmask 255.255.255.0 up
sudo route add default gw 192.168.10.1 dev br0

# Add bridge.sh to /etc/rc.local
#echo "bash /var/www/html/bridge.sh" >> /etc/rc.local

# Ensure that Apache and PHP is installed
sudo apt-get -y install apache2 libapache2-mod-php

# Now we need to move the files into the web directory. 
#sudo mv /Web_Files/* /var/www/html

# Now we need to give the current user (pi) permission to use TCPDump
sudo groupadd pcap
sudo usermod -a -G pcap morgan
sudo chgrp pcap /usr/sbin/tcpdump
sudo chmod 750 /usr/sbin/tcpdump
sudo setcap cap_net_raw,cap_net_admin=eip /usr/sbin/tcpdump

# Done