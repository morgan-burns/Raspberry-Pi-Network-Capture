#!/bin/bash

killall tcpdump
